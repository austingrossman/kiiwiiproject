#include "common.h"

void processGenerators(void);
void processEffects(void);

//globals
float *lastBuffer;

unsigned char bcd = 0;
float pitchBend = 1;

int main( int argc, char *argv[] ) {
	unsigned int i;
	
	
	//set up tables
	for (i=0; i<TABLE_SIZE; i++) {
		organTable[i] = 0.75 * sin(2 * PI * i / TABLE_SIZE);
		organTable[i] += 0.2 * sin(4 * PI * i / TABLE_SIZE);
		organTable[i] += 0.15 * sin(6 * PI * i / TABLE_SIZE);
		organTable[i] += 0.2 * sin(12 * PI * i / TABLE_SIZE);
		organTable[i] += 0.12 * sin(14 * PI * i / TABLE_SIZE);
		organTable[i] += 0.05 * sin(16 * PI * i / TABLE_SIZE);
		organTable[i] += 0.09 * sin(18 * PI * i / TABLE_SIZE);
		organTable[i] += 0.004 * sin(20 * PI * i / TABLE_SIZE);
		organTable[i] += 0.008 * sin(22 * PI * i / TABLE_SIZE);
	}
	
	//initialize organs
	for (i=0; i<MAX_CHANNELS; i++)
		organList[i].active = 0;
	
	//setup the mixer
	Mixer_Init();

	Wah_Init();
	wahEffect.inBuffer = mixer.outBuffer;

	Phasor_Init();
	phasorEffect.inBuffer = wahEffect.outBuffer;
	
	Mute_Init();
	muteEffect.inBuffer = phasorEffect.outBuffer;
	
	lastBuffer = muteEffect.outBuffer;
	
	
	SynthInit();

	//burn time until interrupts occur
    while(1) {
		MIDI_Poll();
	}
}


//this routine executes everytime a buffer going to the DAC empties
interrupt void dmax_isr( void ) {
    volatile unsigned *GPTransferEntry;
    static int ppDac;
	static unsigned int counter = 0;
	unsigned int i;
	MIDIEvent *AnalyzeMIDIEvent;

	if( hDmaxDac->regs->DTCR0 & (1<<DAC_TCC) ) { 
		hDmaxDac->regs->DTCR0 = (1<<DAC_TCC); 
	    GPTransferEntry  = (unsigned *)&hDmaxDac->regs->HiPriorityEventTable;
		GPTransferEntry += ((*(hDmaxDac->hiTableEventEntryPtr)>>8)&0x07F);
	    ppDac = GPTransferEntry[2] >> 31;


		if (++counter == 200) {
			L7(-1);
			counter = 0;
		}
			
		AnalyzeMIDIEvent = De_QueueMIDIEvent();
		if (AnalyzeMIDIEvent != NULL) {
			processMIDIEvent(AnalyzeMIDIEvent);		
		}
	
		//process each generator Instance in turn
		processGenerators();

		//process the mixer Instance
		Mixer_ProcessFrame();

		//process each effects Instance in turn
		processEffects();
		
		//fill the buffer	
		for( i=0; i<FRAME_SIZE; i++ ) {
			dmaxDacBuffer[!ppDac][LEFT][CH_0][i]  = (int)(GAIN * lastBuffer[i]);
			dmaxDacBuffer[!ppDac][RIGHT][CH_0][i] = (int)(GAIN * lastBuffer[i]);
		}

	}
}

void processGenerators(void) {
	int i;
	for (i=0; i<MAX_CHANNELS; i++) {
		Organ_ProcessFrame(i);
	}
}

void processEffects(void) {
	Wah_ProcessFrame();
	Phasor_ProcessFrame();
	Mute_ProcessFrame();
}
