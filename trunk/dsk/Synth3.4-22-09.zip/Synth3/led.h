#ifndef _LED_H_
#define _LED_H_

void U1(int i);
void U2(int i);
void M1(int i);
void M2(int i);
void L0(int i);
void L1(int i);
void L2(int i);
void L3(int i);
void L4(int i);
void L5(int i);
void L6(int i);
void L7(int i);


#endif //_LED_H_
