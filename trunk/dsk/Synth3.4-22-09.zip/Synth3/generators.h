#ifndef _GENERATORS_H_
#define _GENERATORS_H_

#include "common.h"


typedef struct Adsr {
	float outBuffer[FRAME_SIZE];
	float attackgain;
	float sustaingain;		//MUST be less than attackgain
	unsigned int attacktime;	//in samples
	unsigned int decaytime;		//in samples
	unsigned int releasetime;	//in samples
	int state;		//quasi-private, set to 3 to enter release phase
	float currentvalue;    //private
	unsigned int inrelease;		//private
} Adsr;

int Adsr_Init(Adsr *this);
int Adsr_ProcessFrame(Adsr *this); //return 0 normal, -1 on error, 1 signals deinit should be called


typedef struct Oscillator {
	float outBuffer[FRAME_SIZE];
	float *table;			//array to waveform to be oscilated
	unsigned int tablesize;
	float freq;
	float currentindex;	//private
} Oscillator;

int Oscillator_Init(Oscillator *this);
int Oscillator_ProcessFrame(Oscillator *this);


typedef struct VariableOscillator {
	float outBuffer[FRAME_SIZE];
	float *freqTable; 		//should be FRAME_SIZE long
	float *table;			//array to waveform to be oscilated
	unsigned int tablesize;
	float freq;
	float currentindex;	//private
} VariableOscillator;

int VariableOscillator_Init(VariableOscillator *this);
int VariableOscillator_ProcessFrame(VariableOscillator *this);



typedef struct Organ {
	float outBuffer[FRAME_SIZE];
	float freq;
	unsigned char midiNote;
	float gain;				//scale the velocity of the note to between 0 and 1;
	unsigned char released;	//set to 1 when noteOff occurs
	unsigned char active; //0 if unactive, 1 if active
	unsigned char finished;
	Oscillator organOsc;		//private
	Adsr envelope;			//private
} Organ;

int Organ_Init(int i);
int Organ_ProcessFrame(int i);
void NewOrgan(unsigned char midiNote, unsigned char velocity);
void ReleaseOrgan(unsigned char midiNote);


/*
typedef struct RandomArpeggio {
	float freq;
	unsigned char midiNote;
	unsigned char velocity;	
	unsigned char released;	//set to 1 when noteOff occurs
	unsigned char active; //0 if unactive, 1 if active
	int currentNote;	//private
	unsigned char shouldCreate;	//private
} RandomArpeggio;

int RandomArpeggio_Init(int i);
int RandomArpeggio_ProcessFrame(int i);
void NewRandomArpeggio(unsigned char midiNote, unsigned char velocity);
void ReleaseRandomArpeggio(unsigned char midiNote);

*/
#endif //_GENERATORS_H_
