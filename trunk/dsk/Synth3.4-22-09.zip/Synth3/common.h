#ifndef _COMMON_H_
#define _COMMON_H_

#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <soc.h>
#include <csl_chip.h>
#include <csl_intc.h>
#include <csl_dmax.h>
#include <csl_mcasp.h>


#define DAC_TCC 2
#define PI					(3.14159265358979f)
#define SAMPLING_PERIOD 	(10.416667E-6)   // 96k
#define SAMPLING_RATE		96000
#define FRAME_SIZE  		80
#define MAX_CHANNELS 		16
#define TABLE_SIZE			4096
#define QUEUE_SIZE 			32
#define GAIN				2000000000
#define LN2DIV12 			0.057762265f

#include "PADK.h"

#include "initialization.h"
#include "generators.h"
#include "effects.h"
#include "mixer.h"
#include "midi.h"
#include "led.h"

//globals
extern Mixer mixer;
extern float *lastBuffer;

extern unsigned char bcd;

extern Organ organList[MAX_CHANNELS];

extern float organTable[TABLE_SIZE];

extern float pitchBend;

#endif //_COMMON_H_
