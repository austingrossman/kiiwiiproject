#include "common.h"


int Adsr_Init(Adsr *this) {
	this->state = 0;  //state 0 is the attack phase
	this->currentvalue = 0;
	this->inrelease = 0;
	return 0;
}

int Adsr_ProcessFrame(Adsr *this) {
	int index;
	float value, increment;

	float *outBuffer;		
	float attackgain;
	float sustaingain;
	unsigned int attacktime;
	unsigned int decaytime;	
	unsigned int releasetime;
	int state;	
	float currentvalue;

	outBuffer = this->outBuffer;
	attackgain  = this->attackgain;
	sustaingain = this->sustaingain;
	attacktime = this->attacktime;
	decaytime = this->decaytime;
	releasetime = this->releasetime;
	state = this->state;
	currentvalue = this->currentvalue;

	if (state == 0) { //attack phase
		//calculate slope
		increment = attackgain / attacktime;

		//calculate first value
		value = currentvalue;

		//fill buffer until frame ends or attack ends
		for (index = 0; (index<FRAME_SIZE) && (value<=attackgain); index++) {
			outBuffer[index] = value;
			value += increment;
		}

		//do decay if we didn't finish the frame
		if (index < FRAME_SIZE) {
			state = 1; //decay phase
			increment = (sustaingain - attackgain) / decaytime;
			value = attackgain + increment;
			//fill buffer until frame ends or attack ends
			for (; (index<FRAME_SIZE) && (value>=sustaingain); index++) {
				outBuffer[index] = value;
				value += increment;
			}

			//do sustain if we didn't finish the frame,  i.e. decay time is short
			if (index < FRAME_SIZE) {
				state = 2; //sustain phase
				value = sustaingain;
				//fill buffer until frame ends
				for (; index < FRAME_SIZE; index++) {
					outBuffer[index] = value;
				}
			}
		}

	} else if (state == 1) { //decay phase
		//calculate slope
		increment = (sustaingain - attackgain) / decaytime;

		//calculate first value
		value = currentvalue;

		//fill buffer until frame ends or decay ends
		for (index = 0; (index<FRAME_SIZE) && (value>=sustaingain); index++) {
			outBuffer[index] = value;
			value += increment;
		}

		//do sustain if we didn't finish the frame
		if (index < FRAME_SIZE) {
			state = 2; //sustain phase
			value = sustaingain;
			//fill buffer until frame ends
			for (; index < FRAME_SIZE; index++) {
				outBuffer[index] = value;
			}
		}

	} else if (state == 2) { //sustain phase
		//fill buffer until frame ends
		value = sustaingain;
		for (index = 0; index<FRAME_SIZE; index++) {
			outBuffer[index] = value;
		}

	} else if (state == 3) { //release phase
		if (this->inrelease == 0) { //if this is the first frame in release phase
			sustaingain = currentvalue;		//this fixes the case where the Adsr
			this->sustaingain = currentvalue;  //wasn't in sustain before release
			this->inrelease = 1;
		}
		
		increment = -sustaingain / releasetime;
		value = currentvalue + increment;
		
		//fill buffer until frame ends or release ends
		for (index = 0; (index<FRAME_SIZE) && (value>=0); index++) {
			outBuffer[index] = value;
			value += increment;
		}
		//fill with zeros if we didn't finish the frame
		if (index < FRAME_SIZE) {
			for (; index < FRAME_SIZE; index++) {
				outBuffer[index] = 0;
			}
			return 1; //Adsr should be destroyed
		}
	}

	this->state = state;
	this->currentvalue = value;

	return 0;
}




int Oscillator_Init(Oscillator *this) {
	this->currentindex = 0;
	return 0;
}

int Oscillator_ProcessFrame(Oscillator *this) {
	float *outBuffer, *table, freq, index, increment;
	unsigned int tablesize, i;

	outBuffer = this->outBuffer;
	table = this->table;
	tablesize = this->tablesize;
	freq = this->freq;
	
	increment = SAMPLING_PERIOD * freq * tablesize;
	index = this->currentindex;

	for (i = 0; i < FRAME_SIZE; i++) {
		if (index >= tablesize)
			index -= tablesize;
		outBuffer[i] = table[(int)(index)]; 
		index += increment;
	}

	this->currentindex = index;
	return 0;
}


int VariableOscillator_Init(VariableOscillator *this) {
	this->currentindex = 0;
	return 0;
}

int VariableOscillator_ProcessFrame(VariableOscillator *this) {
	float *outBuffer, *table, *freqTable, index, increment;
	unsigned int tablesize, i;

	outBuffer = this->outBuffer;
	table = this->table;
	tablesize = this->tablesize;
	freqTable = this->freqTable;
	
	index = this->currentindex;

	for (i = 0; i < FRAME_SIZE; i++) {
		if (index >= tablesize)
			index -= tablesize;
		outBuffer[i] = table[(int)(index)]; 
		increment = SAMPLING_PERIOD * freqTable[i] * tablesize;
		index += increment;
	}

	this->currentindex = index;
	return 0;
}



float	organTable[TABLE_SIZE];
Organ organList[MAX_CHANNELS];

int Organ_Init(int i) {
	organList[i].released = 0;
	organList[i].active = 1;
	organList[i].finished = 0;
	organList[i].organOsc.table = organTable;
	organList[i].organOsc.tablesize = TABLE_SIZE;
	organList[i].envelope.attackgain = 1*organList[i].gain;
	organList[i].envelope.sustaingain = 0.6*organList[i].gain;
	organList[i].envelope.attacktime = 2000;
	organList[i].envelope.decaytime = 2500;
	organList[i].envelope.releasetime = 4000;
	Oscillator_Init(&(organList[i].organOsc));
	Adsr_Init(&(organList[i].envelope));
	return 0;
}

int Organ_ProcessFrame(int i) {
	float *outBuffer, *oscBuffer, *envelopeBuffer;
	int j, k;

	if (organList[i].active == 0) {
		return 0;
	}
	if (organList[i].finished == 1) {
		organList[i].active = 0;
		return 0;
	}
	
	outBuffer = organList[i].outBuffer;
	oscBuffer = organList[i].organOsc.outBuffer;
	envelopeBuffer = organList[i].envelope.outBuffer;

	organList[i].organOsc.freq = organList[i].freq * pitchBend;

	if (organList[i].released == 1) organList[i].envelope.state = 3;

	Oscillator_ProcessFrame(&(organList[i].organOsc));

	j = Adsr_ProcessFrame(&(organList[i].envelope));
	
	for (k = 0; k < FRAME_SIZE; k++) {
		outBuffer[k] = oscBuffer[k] * envelopeBuffer[k];
	}
	
	if (j == 1) organList[i].finished = 1;
	return j;
}


void NewOrgan(unsigned char midiNote, unsigned char velocity) {	
	unsigned int i;
	
/*	for (i = 0; i < MAX_CHANNELS; i++) {
		if ((organList[i].active == 1)
		  &&(organList[i].midiNote == midiNote)) 
			return;
	}*/
	
	i = 0;
	while ( (organList[i].active !=0) && (i < MAX_CHANNELS) ) {
		i++;	
	}

	if (i == MAX_CHANNELS)
		return;
		
	
	organList[i].midiNote = midiNote;
	organList[i].freq = 440 * expf(((float)midiNote - 69) * LN2DIV12); //formula for converting MIDI "notes" to frequency
	organList[i].gain = (float)(velocity) / 127; //scale velocity to between 0 and 1
	Organ_Init(i);
	
	return;
}

void ReleaseOrgan(unsigned char midiNote){
	int i;
	
	for (i = 0; i < MAX_CHANNELS; i++) {
		if (organList[i].active == 1) {
			if (organList[i].midiNote == midiNote){
				organList[i].released = 1;
			}
		}
	}
}

/*
RandomArpeggio rarpeggioList[MAX_CHANNELS];

int RandomArpeggio_Init(int i) {
	rarpeggioList[i].released = 0;
	rarpeggioList[i].active = 1;
	rarpeggioList[i].shouldCreate = 1;
	return 0;
}

int RandomArpeggio_ProcessFrame(int i) {
	int j;

	if (rarpeggioList[i].active == 0) {
		return 0;
	}
	if (rarpeggioList[i].released == 1) {
		if (organList[currentNote].released = 1;
		rarpeggioList[i].active = 0;
		return 0;
	}
	if (rarpeggioList[i].shouldCreate == 1) {
		rarpeggioList[i].shouldCreate = 0;
	}
	
	
	if (j == 1) rarpeggioList[i].finished = 1;
	return j;
}


void NewRandomArpeggio(unsigned char midiNote, unsigned char velocity) {	
	unsigned int i;
	
	for (i = 0; i < MAX_CHANNELS; i++) {
		if ((rarpeggioList[i].active == 1)
		  &&(rarpeggioList[i].midiNote == midiNote)) 
			return;
	}
	
	i = 0;
	while ( (rarpeggioList[i].active !=0) && (i < MAX_CHANNELS) ) {
		i++;	
	}

	if (i == MAX_CHANNELS)
		return;
		
	
	rarpeggioList[i].midiNote = midiNote;
	rarpeggioList[i].freq = 440 * expf(((float)midiNote - 69) * LN2DIV12); //formula for converting MIDI "notes" to frequency
	rarpeggioList[i].gain = (float)(velocity) / 127; //scale velocity to between 0 and 1
	RandomArpeggio_Init(i);
	
	return;
}

void ReleaseRandomArpeggio(unsigned char midiNote){
	int i;
	
	for (i = 0; i < MAX_CHANNELS; i++) {
		if (rarpeggioList[i].active == 1) {
			if (rarpeggioList[i].midiNote == midiNote){
				rarpeggioList[i].released = 1;
			}
		}
	}
}*/