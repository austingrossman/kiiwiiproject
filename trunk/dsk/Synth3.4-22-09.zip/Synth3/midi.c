#include "common.h"

//globals
MIDIEvent MIDIEventArray[QUEUE_SIZE];
int  MIDIQueueIndex_In = 0; //circular Queue/Buffer in ptr
int  MIDIQueueIndex_Out = 0; //circular Queue/Buffer out ptr

int HarmonizerEffectOnFlag = 0;
int firstNoteFlag = 0;
unsigned char keyOffset = 0; //default scale will be in the key of C -> range of keyOffset is 0 - 11
//start my code
int harmonizerScaleSelect = 0;
unsigned char Key;
unsigned int scaleLUT_Index;
//unsigned int selectedScale = 1;

#define NUM_BLCK_KEYS 53
#define NUM_WHITE_KEYS 75
#define JAP_SCALE_NUM_NOTES 55
#define HAR_MIN_SCALE_NUM_NOTES 75
#define NUMOFHARM_SCALES 2


/************** SCALES LUT *************************
****
** NOTES: if it works with one test scale it will work with all?
** Middle C is dec: 60, hex: 3C
*************************************************/
// the Japanese scale
unsigned char JAPANESE[56] = {0x38, //dec 56 -> size of array
0x00,0x01,0x05,0x07,0x08, //Octave -1
0x0C,0x0D,0x11,0x13,0x14, //Octave 0
0x18,0x19,0x1D,0x1F,0x20, //Octave 1
0x24,0x25,0x29,0x2B,0x2C, //Octave 2
0x30,0x31,0x35,0x37,0x38, //Octave 3
0x3C,0x3D,0x41,0x43,0x44, //Octave 4
0x48,0x49,0x4D,0x4F,0x50, //Octave 5
0x54,0x55,0x59,0x5B,0x5C, //Octave 6
0x60,0x61,0x65,0x67,0x68, //Octave 7
0x6C,0x6D,0x71,0x73,0x74, //Octave 8
0x78,0x79,0x7D,0x7F}; //Octave 9 

// the Harmonic Minor scale
unsigned char HARMONIC_MINOR[76] = {0x4C, //dec 76 -> size of array
0x00,0x02,0x03,0x05,0x07,0x08,0x0B, //Octave -1
0x0C,0x0E,0x0F,0x11,0x13,0x14,0x17, //Octave 0
0x18,0x1A,0x1B,0x1D,0x1F,0x20,0x23, //Octave 1
0x24,0x26,0x27,0x29,0x2B,0x2C,0x2F, //Octave 2
0x30,0x32,0x33,0x35,0x37,0x38,0x3B, //Octave 3
0x3C,0x3E,0x3F,0x41,0x43,0x44,0x47, //Octave 4
0x48,0x4A,0x4B,0x4D,0x4F,0x50,0x53, //Octave 5
0x54,0x56,0x57,0x59,0x5B,0x5C,0x5F, //Octave 6
0x60,0x62,0x63,0x65,0x67,0x68,0x6B, //Octave 7
0x6C,0x6E,0x6F,0x71,0x73,0x74,0x77, //Octave 8
0x78,0x7A,0x7B,0x7D,0x7F}; //Octave 9 


// the WHITEKEYS values checked are db1 of a MIDI event
unsigned char WHITEKEYS[75] = {0x00,0x02,0x04,0x05,0x07,0x09,0x0B, //Octave -1
0x0C,0x0E,0x10,0x11,0x13,0x15,0x17, //Octave 0
0x18,0x1A,0x1C,0x1D,0x1F,0x21,0x23, //Octave 1
0x24,0x26,0x28,0x29,0x2B,0x2D,0x2F, //Octave 2
0x30,0x32,0x34,0x35,0x37,0x39,0x3B, //Octave 3
0x3C,0x3E,0x40,0x41,0x43,0x45,0x47, //Octave 4
0x48,0x4A,0x4C,0x4D,0x4F,0x51,0x53, //Octave 5
0x54,0x56,0x58,0x59,0x5B,0x5D,0x5F, //Octave 6
0x60,0x62,0x64,0x65,0x67,0x69,0x6B, //Octave 7
0x6C,0x6E,0x70,0x71,0x73,0x75,0x77, //Octave 8
0x78,0x7A,0x7C,0x7D,0x7F }; //Octave 9 


// the BLACKKEYS values checked are db1 of a MIDI event
unsigned char BLACKKEYS[53] = {0x01,0x03,0x06,0x08,0x0A, //Octave -1
0x0D,0x0F,0x12,0x14,0x16, //Octave 0
0x19,0x1B,0x1E,0x20,0x22, //Octave 1
0x25,0x27,0x2A,0x2C,0x2E, //Octave 2
0x31,0x33,0x36,0x38,0x3A, //Octave 3
0x3D,0x3F,0x42,0x44,0x46, //Octave 4
0x49,0x4B,0x4E,0x50,0x52, //Octave 5
0x55,0x57,0x5A,0x5C,0x5E, //Octave 6
0x61,0x63,0x66,0x68,0x6A, //Octave 7
0x6D,0x6F,0x72,0x74,0x76, //Octave 8
0x79,0x7B,0x7E }; //Octave 9 

/************** SCALES *************************
**
*************************************************/
unsigned char *harmonizerScales[NUMOFHARM_SCALES];    
//end my code


void QueueMIDIEvent( MIDIEvent fullEventAssignIn){
    MIDIEventArray[(MIDIQueueIndex_In)++] = fullEventAssignIn;
	if(MIDIQueueIndex_In == QUEUE_SIZE){MIDIQueueIndex_In = 0;}
}

void QueueMIDIEvent2( unsigned char sb, unsigned char db1, unsigned char db2) {
	MIDIEvent event;
	event.sb=sb;
	event.db1=db1;
	event.db2=db2;
	event.db3=0;
	QueueMIDIEvent(event);
}

MIDIEvent* De_QueueMIDIEvent(void){
	if(MIDIQueueIndex_Out == QUEUE_SIZE){MIDIQueueIndex_Out = 0;} //if count is more than QUEUE_SIZE, then wrap around back to 0
	if(MIDIQueueIndex_Out == MIDIQueueIndex_In){ return NULL; }
	return MIDIEventArray + MIDIQueueIndex_Out++;

}

ScaleHarmonizer(MIDIEvent *event){
  unsigned char tempDB1,keyInput; 
  unsigned int index = 0;
  
  harmonizerScales[1] = JAPANESE;
  harmonizerScales[0] = HARMONIC_MINOR;

if( firstNoteFlag ){  //We only set the Key when we first turn on harmonizer effect
  keyInput = event->db1;
  while( keyInput > 0x71 || keyInput < 0x60){
     if( keyInput > 0x71){keyInput = keyInput - 0x0C;}
	 if( keyInput < 0x60){keyInput = keyInput + 0x0C;}
  }
  switch(keyInput){ //Key offset(hex value) will be first note played after effect is turned on
    case 0x60: keyOffset = 0x00; L5(-1); break;
    case 0x61: keyOffset = 0x01; break;
    case 0x62: keyOffset = 0x02; break;
    case 0x63: keyOffset = 0x03; break;
    case 0x64: keyOffset = 0x04; break;
    case 0x65: keyOffset = 0x05; break;
    case 0x66: keyOffset = 0x06; break;
    case 0x67: keyOffset = 0x07; break;
    case 0x68: keyOffset = 0x08; break;
    case 0x69: keyOffset = 0x09; break;
    case 0x70: keyOffset = 0x0A; break;
    case 0x71: keyOffset = 0x0B; break;
    default: keyOffset = 0x00; L4(-1);   //if the key is not in the range then default to key of C
    }
	firstNoteFlag = 0;  //Can only change key when we turn effect OFF then ON
	//L0(-1);
	//return;
}

    for(index = 0; index < NUM_BLCK_KEYS; index++){
       if(event->db1 == BLACKKEYS[index]){
         event->db1 = 0x01; //note 1 
	     event->db2 = 0x00; //vel 0  -> no sound
       }
    }

    tempDB1 = event->db1;
    for(index = 0; index < NUM_WHITE_KEYS; index++){
       if(tempDB1==WHITEKEYS[index]){
         scaleLUT_Index = index; //use the index of found white key to play "correct" note in specified scale
         if(scaleLUT_Index < harmonizerScales[harmonizerScaleSelect][0]){ // < size of scale array 
            event->db1 = harmonizerScales[harmonizerScaleSelect][scaleLUT_Index] + keyOffset;
         }else{event->db1 = 0x00; event->db2 = 0x00; }//DB2 = 0x00} //default to note 0 velocity 0
        }
    }
} 

#define NOTEON			     0x90
#define NOTEOFF			     0x80
#define PITCHBEND		     0xE0
#define	CONTROLCHANGE     	 0xB0
#define VOLUME 	    		 0x07
#define WAHPARAM		     0x01
#define WAHWET		    	 0x54
#define PHASORPARAM	    	 0x46
#define PHASORWET	    	 0x05
#define SCALEHARMONIZER	     0x19
#define LEFTSCALEHARMSELECT  0X15
#define RIGHTSCALEHARMSELECT 0X16
#define MUTE		         0x14

void processMIDIEvent(MIDIEvent *event) {
	int channel;
   	
	if(HarmonizerEffectOnFlag && (event->sb & 0xF0) == NOTEON){
	   ScaleHarmonizer(event);
	}
	channel = event->sb & 0x0F;
	

	if (((event->sb & 0xF0) == NOTEON)&&(event->db2 != 0)) {
//		if (channel == 0) { //organ
			//if (HarmonizerEffectOnFlag) {
				//ScaleHarmonizer(event);
			//}
			NewOrgan(event->db1, event->db2);
//		}
	} else if (((event->sb & 0xF0) == NOTEOFF)||((event->sb & 0xF0) == NOTEON)){ //noteOff event
	//	if (channel == 0) {
			ReleaseOrgan(event->db1);
	//	}

	} else if ((event->sb & 0xF0) == PITCHBEND) { //pitchbend
		if ((event->db1 == 0x00)||(event->db1 == 0x7F && event->db2 == 0x7F)) {
			pitchBend = expf((((float)event->db2-64)/16) * LN2DIV12);
		}
			
	} else if ((event->sb & 0xF0) == CONTROLCHANGE) {
		if ((event->db1) == VOLUME) {  //volume
			mixer.gain = (float)event->db2 / 127;
			
		} else if ((event->db1) == WAHPARAM) { //wah parameter
			wahEffect.parameter = (float)event->db2 / 127;
			
		} else if ((event->db1) == WAHWET) {
			wahEffect.wet = (float)event->db2 / 127;
		
		} else if ((event->db1) == PHASORPARAM) {
			phasorEffect.parameter = (float)event->db2 / 127;
			
		} else if ((event->db1) == PHASORWET) {
			phasorEffect.wet = (float)event->db2 / 127;
			
		} else if ((event->db1) == SCALEHARMONIZER) {
			L2(-1);
			if( HarmonizerEffectOnFlag == 0 ){HarmonizerEffectOnFlag = 1; firstNoteFlag = 1;}  //Turn on harmonizer effect 
			else{HarmonizerEffectOnFlag = 0;}  //Turn off Harmonizer effect
			
		}else if ((event->db1) == LEFTSCALEHARMSELECT) {
		    if( (harmonizerScaleSelect -1) == -1){ harmonizerScaleSelect = NUMOFHARM_SCALES - 1; }
			else{harmonizerScaleSelect = (harmonizerScaleSelect - 1);}
			
		}else if ((event->db1) == RIGHTSCALEHARMSELECT) {
			harmonizerScaleSelect = (harmonizerScaleSelect +1)%NUMOFHARM_SCALES;
			
		}else if ((event->db1) == MUTE) {
			muteEffect.active = muteEffect.active ^ 0x01;
			
		}
	}
	
	/*L0(event->sb & 0x01);
	L1(event->sb & 0x02);
	L2(event->sb & 0x04);
	L3(event->sb & 0x08);
	L4(event->sb & 0x10);
	L5(event->sb & 0x20);
	L6(event->sb & 0x40);
	GPIO_SetBCD(event->db1);*/
}


void MIDI_Poll(void) {
	unsigned char data;
	static MIDIEvent event;
	
	MIDI_Read(&data, 1, 1);
	if (data >= 0x80) { //if status byte
		event.sb = data;
		return;
	}
	event.db1 = data;
	
	MIDI_Read(&data, 1, 1);
	if (data >= 0x80) { 
		event.sb = data;
		return;
	}
	event.db2 = data;
		
	QueueMIDIEvent(event);
	M1(-1);
}
